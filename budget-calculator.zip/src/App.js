import React, { useState } from 'react';
import './App.css';
import Alert from './components/Alert';
import ExpenseForm from './components/ExpenseForm';
import ExpenseList from './components/ExpenseList';

function App() {
  const initialExpense = [
    {
      id: 1, charge: 'Rent', amount: 1400
    },
    {
      id: 2, charge: 'Car Pay', amount: 1700
    },
    {
      id: 3, charge: 'Groseery', amount: 400
    }
  ];

  //alert 
  const [alert, setAlert] = useState({ show: false });

  //expense 
  const [expense, setExpense] = useState(initialExpense);

  //charge
  const [charge, setCharge] = useState('');

  //amount 
  const [amount, setAmount] = useState(0);

  //edited id
  const [id, setId] = useState(0);

  //edit button
  const [edit, setEdit] = useState(false);

  //handleCharge
  function handleCharge(e) {
    setCharge(e.target.value);
  }

  //handleAmount
  function handleAmount(e) {
    setAmount(e.target.value);
  }

  //handleAlert
  function handleAlert({ type, text }) {
    setAlert({ show: true, type, text });
    setTimeout(() => {
      setAlert(false);
    }, 3000)
  }

  //handleSubmit
  function handleSubmit(e) {
    e.preventDefault();
    if (charge !== '' && amount > 0) {
      if (edit) {
        let tempExpense = expense.map((items) => {
        return items.id === id ? {...items, charge, amount} : items
        });
        setExpense(tempExpense);
        setEdit(false);
        handleAlert({ show: true, type: "success", text: "Successfully Edited!!" });
        }else{
         const singleExpense = { id: new Date().getTime(), charge, amount };
        setExpense([...expense, singleExpense]);
        handleAlert({ show: true, type: "success", text: "Successfully inserted!!" });
        }
      setCharge('');
      setAmount('');
    } else {
      handleAlert({ type: "danger", text: "Nothing is entered.. PLease enter some value!!" })
    }
  }

  //clearItems
  function clearItems() {
    setExpense([])
  }

  //deleteHandler
  function deleteHandler(id) {
    const filterData = expense.filter((item) => {
      return item.id !== id
    });
    setExpense(filterData);
  }

  //editHandler
  function editHandler(id) {
    const editedItem = expense.find(item => item.id === id);
    let { charge, amount } = editedItem;
    console.log(charge)
    setCharge(charge);
    setAmount(amount);
    setEdit(true);
    setId(id);
  }


  return (
    <>
      {alert.show && <Alert type={alert.type} text={alert.text} />}
      <h1>Budget Calculator</h1>
      <main className="App">
        <ExpenseForm
          charge={charge}
          amount={amount}
          handleCharge={handleCharge}
          handleAmount={handleAmount}
          handleSubmit={handleSubmit}
          edit={edit}
        />
        <ExpenseList expense={expense}
          deleteHandler={deleteHandler}
          editHandler={editHandler}
          clearItems={clearItems}
        />
      </main>
      <h1>
        Total Spending : <span className="total">
          ${expense.reduce((acc, cur) => {
        return (acc += parseInt(cur.amount))
      }, 0)}
        </span>
      </h1>
    </>
  );
}

export default App;
