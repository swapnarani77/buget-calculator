import React from 'react';
import ExpenseItem from './ExpenseItem';
import {MdDelete} from 'react-icons/md';

function ExpenseList({expense,clearItems, editHandler, deleteHandler}){
    return(
<>
<ul className="list">
<ExpenseItem expense={expense} deleteHandler={deleteHandler} editHandler={editHandler}/>
</ul>
<button className="btn" onClick={clearItems}> Clear Expenses <MdDelete className="btn-icon"/></button>
</>
    );
}

export default ExpenseList;