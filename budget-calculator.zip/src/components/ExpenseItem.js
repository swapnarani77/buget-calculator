import React from 'react';


function ExpenseItem({expense, editHandler, deleteHandler}){
    return(
<>
{expense.map((item) => {
    return <li className="item" key={item.id}>
    <div className="info">
        <span className="expense">{item.charge}</span>
        <span className="amount">${item.amount}</span></div>
    <div>
        <button className="edit-btn" aria-label="edit button" onClick={() => editHandler(item.id)}>
            <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 24 24" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                <path d="M3 17.25V21h3.75L17.81 9.94l-3.75-3.75L3 17.25zM20.71 7.04c.39-.39.39-1.02 0-1.41l-2.34-2.34c-.39-.39-1.02-.39-1.41 0l-1.83 1.83 3.75 3.75 1.83-1.83z"></path>
            </svg>
        </button>
        <button className="clear-btn" aria-label="delete button" onClick={() => deleteHandler(item.id)}>
            <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 24 24" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                <path d="M6 19c0 1.1.9 2 2 2h8c1.1 0 2-.9 2-2V7H6v12zM19 4h-3.5l-1-1h-5l-1 1H5v2h14V4z"></path>
            </svg>
        </button>
    </div>
</li>
})}
</>
    );
}

export default ExpenseItem;